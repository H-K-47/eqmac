EQMac / The Al'Kabor Project (http://www.takproject.net/forums/)
Mouse Wheel Zooming/Scrolling Patch by sodcheats

Modified the game to allow scrolling in
and out of third person view and zooming
using the mouse wheel.

Make a backup of the original file in case you want to
revert the changes or experience problems with this patch.

The eqgame.exe that is used is from the eqmule patch:
http://www.redguides.com/forums/showthread.php/26254-OFFICIAL-EQMac-Windows-eqmules-Edition-standalone-v2-1
EQMac-Windows-eqmules-Edition-standalone-v2.1.zip
EQMac-Windows-eqmules-Edition-standalone-v2.2.zip

////////////////////////////////////////////////////////////////

The eqgame.exe has been modified in the following way:

Offset: 15B2EC
Bytes: E9 0F 71 08 00 90 90 90 90

Offset: 1E2400
Bytes: 8B 44 24 0C 89 05 04 90 79 00 FF 74 24 0C E8 AD CD FB FF E9 DD 8E F7 FF

Offset: 19F225
Bytes: E9 F6 31 04 00

Offset: 1E2420
Bytes: 85 FF 0F 85 4F 01 00 00 A1 78 94 80 00 8B 80 AC 05 00 00 83 F8 05 0F 85 3B 01 00 00 A1 04 90 79 00 85 C0 0F 84 2E 01 00 00 83 F8 78 0F 84 05 00 00 00 E9 1B 00 00 00 0F BE 05 68 BE 63 00 83 F8 02 0F 84 2F 00 00 00 0F 8F 65 00 00 00 E9 05 01 00 00 0F BE 05 68 BE 63 00 83 F8 00 0F 84 6F 00 00 00 83 F8 02 0F 84 66 00 00 00 0F 8F DA 00 00 00 E9 E1 00 00 00 A1 CC 94 7F 00 8D 80 90 00 00 00 D9 05 C0 96 79 00 D8 18 DF E0 9E 0F 86 20 00 00 00 A1 CC 94 7F 00 8D 80 90 00 00 00 D9 05 C0 96 79 00 D8 20 D8 20 D9 1D C0 96 79 00 E9 A5 00 00 00 C6 05 68 BE 63 00 00 A1 CC 94 7F 00 8D 80 90 00 00 00 D9 00 D9 1D C0 96 79 00 E9 86 00 00 00 0F BE 05 68 BE 63 00 83 F8 00 0F 84 3A 00 00 00 E9 00 00 00 00 D9 05 C0 96 79 00 D8 1D 38 85 5E 00 DF E0 9E 0F 87 3F 00 00 00 A1 CC 94 7F 00 8D 80 90 00 00 00 D9 05 C0 96 79 00 D8 00 D8 00 D9 1D C0 96 79 00 E9 3C 00 00 00 C6 05 68 BE 63 00 02 A1 CC 94 7F 00 8D 80 90 00 00 00 D9 00 D9 1D C0 96 79 00 E9 1D 00 00 00 D9 05 38 85 5E 00 D9 1D C0 96 79 00 E9 0C 00 00 00 C6 05 68 BE 63 00 02 E9 00 00 00 00 8B 46 34 39 C7 E9 A9 CC FB FF

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

This is the assembly code for the patch:

// Jump to Cave Cave #1
eqgame.exe+15B2EC:
eqgame.exe+15B2EC - E9 0F710800           - jmp eqgame.exe+1E2400
eqgame.exe+15B2F1 - 90                    - nop
eqgame.exe+15B2F2 - 90                    - nop
eqgame.exe+15B2F3 - 90                    - nop
eqgame.exe+15B2F4 - 90                    - nop


// Code Cave #1
// this handles the mouse wheel delta value
// the value is in [esp+0C]
// we store the value at [eqgame.exe+399004] for later use
// a value of 120 is scroll up, -120 is scroll down
eqgame.exe+1E2400:
eqgame.exe+1E2400 - 8B 44 24 0C           - mov eax,[esp+0C] // mov the mouse wheel delta to eax
eqgame.exe+1E2404 - 89 05 04907900        - mov [eqgame.exe+399004],eax // store the mouse wheel delta value at eqgame.exe+399004
eqgame.exe+1E240A - FF 74 24 0C           - push [esp+0C] // mouse wheel delta value
eqgame.exe+1E240E - E8 ADCDFBFF           - call eqgame.exe+19F1C0 // call the mouse wheel scroll function
eqgame.exe+1E2413 - E9 DD8EF7FF           - jmp eqgame.exe+15B2F5 // jump to the original code that comes after the jump to code cave #1


// Jump to Code Cave #2
eqgame.exe+19F225:
eqgame.exe+19F225 - E9 F6310400           - jmp eqgame.exe+1E2420


// Code Cave #2
// this handles the mouse wheel scrolling event
// if you are in first person, it will zoom out the camera to third person view
// if you are in third person, it will zoom in and out
// if you zoom in to the minimum value, it will zoom in the camera to first person view
// if you are in the other third person camera views, scrolling up will zoom in the camera to first person view
// if you are in the other third person camera views, scrolling down will zoom out the camera to third person view
// the zoom minimum value is [spawn+00000090] or spawn camera height offset
// the zoom maximum value is [eqgame.exe+1E8538] which equals 200.0
// the zoom sensitivity value is the zoom minimum value multiplied by two
eqgame.exe+1E2420:
eqgame.exe+1E2420 - 85 FF                 - test edi,edi // check if the mouse is hovering over a CXWnd (the UI)
eqgame.exe+1E2422 - 0F85 4F010000         - jne eqgame.exe+1E2577 // goto original code, let the game scroll UI scrollbars like in the Main Chat window
eqgame.exe+1E2428 - A1 78948000           - mov eax,[eqgame.exe+409478] // CEverQuest
eqgame.exe+1E242D - 8B 80 AC050000        - mov eax,[eax+000005AC] // offset to game state
eqgame.exe+1E2433 - 83 F8 05              - cmp eax,05 // check if in game
eqgame.exe+1E2436 - 0F85 3B010000         - jne eqgame.exe+1E2577 // goto original code
eqgame.exe+1E243C - A1 04907900           - mov eax,[eqgame.exe+399004] // mouse wheel delta value that was stored here in the first code cave
eqgame.exe+1E2441 - 85 C0                 - test eax,eax // check if the mouse wheel delta value is NULL
eqgame.exe+1E2443 - 0F84 2E010000         - je eqgame.exe+1E2577 // goto original code
eqgame.exe+1E2449 - 83 F8 78              - cmp eax,78 // check if the mouse wheel delta value equals scroll up
eqgame.exe+1E244C - 0F84 05000000         - je eqgame.exe+1E2457 // goto wheel up
eqgame.exe+1E2452 - E9 1B000000           - jmp eqgame.exe+1E2472 // goto wheel down
wheel up:
eqgame.exe+1E2457 - 0FBE 05 68BE6300      - movsx eax,byte ptr [eqgame.exe+23BE68] // camera view value
eqgame.exe+1E245E - 83 F8 02              - cmp eax,02 // check if camera view value is third person
eqgame.exe+1E2461 - 0F84 2F000000         - je eqgame.exe+1E2496 // goto zoom in
eqgame.exe+1E2467 - 0F8F 65000000         - jg eqgame.exe+1E24D2 // goto zoom in from third person
eqgame.exe+1E246D - E9 05010000           - jmp eqgame.exe+1E2577 // goto original code
wheel down:
eqgame.exe+1E2472 - 0FBE 05 68BE6300      - movsx eax,byte ptr [eqgame.exe+23BE68] // camera view value
eqgame.exe+1E2479 - 83 F8 00              - cmp eax,00 // check if camera view value is first person
eqgame.exe+1E247C - 0F84 6F000000         - je eqgame.exe+1E24F1 // goto zoom out
eqgame.exe+1E2482 - 83 F8 02              - cmp eax,02 // check if camera view value is third person
eqgame.exe+1E2485 - 0F84 66000000         - je eqgame.exe+1E24F1 // goto zoom out
eqgame.exe+1E248B - 0F8F DA000000         - jg eqgame.exe+1E256B // goto set camera view to third person
eqgame.exe+1E2491 - E9 E1000000           - jmp eqgame.exe+1E2577 // goto original code
zoom in:
eqgame.exe+1E2496 - A1 CC947F00           - mov eax,[eqgame.exe+3F94CC] // player spawn
eqgame.exe+1E249B - 8D 80 90000000        - lea eax,[eax+00000090] // offset to camera height offset, this is the zoom minimum value
eqgame.exe+1E24A1 - D9 05 C0967900        - fld dword ptr [eqgame.exe+3996C0] // load third person camera zoom value
eqgame.exe+1E24A7 - D8 18                 - fcomp dword ptr [eax] // compare to zoom minimum value
eqgame.exe+1E24A9 - DFE0                  - fnstsw ax
eqgame.exe+1E24AB - 9E                    - sahf 
eqgame.exe+1E24AC - 0F86 20000000         - jbe eqgame.exe+1E24D2 // if below or equal to zoom minimum value goto zoom in from third person
eqgame.exe+1E24B2 - A1 CC947F00           - mov eax,[eqgame.exe+3F94CC] // player spawn
eqgame.exe+1E24B7 - 8D 80 90000000        - lea eax,[eax+00000090] // offset to camera height offset, this is the zoom minimum value
eqgame.exe+1E24BD - D9 05 C0967900        - fld dword ptr [eqgame.exe+3996C0] // load third person camera zoom value
eqgame.exe+1E24C3 - D8 20                 - fsub dword ptr [eax] // subtract twice to multiply by two
eqgame.exe+1E24C5 - D8 20                 - fsub dword ptr [eax] // subtract twice to multiply by two
eqgame.exe+1E24C7 - D9 1D C0967900        - fstp dword ptr [eqgame.exe+3996C0] // store to third person camera zoom value
eqgame.exe+1E24CD - E9 A5000000           - jmp eqgame.exe+1E2577 // goto original code
zoom in from third person:
eqgame.exe+1E24D2 - C6 05 68BE6300 00     - mov byte ptr [eqgame.exe+23BE68],00 // set camera view to first person
eqgame.exe+1E24D9 - A1 CC947F00           - mov eax,[eqgame.exe+3F94CC] // player spawn
eqgame.exe+1E24DE - 8D 80 90000000        - lea eax,[eax+00000090] // offset to camera height offset, this is the zoom minimum value
eqgame.exe+1E24E4 - D9 00                 - fld dword ptr [eax] // load zoom minimum value
eqgame.exe+1E24E6 - D9 1D C0967900        - fstp dword ptr [eqgame.exe+3996C0] // store to third person camera zoom value
eqgame.exe+1E24EC - E9 86000000           - jmp eqgame.exe+1E2577 // goto original code
zoom out:
eqgame.exe+1E24F1 - 0FBE 05 68BE6300      - movsx eax,byte ptr [eqgame.exe+23BE68] // camera view value
eqgame.exe+1E24F8 - 83 F8 00              - cmp eax,00 // check if camera view value is first person
eqgame.exe+1E24FB - 0F84 3A000000         - je eqgame.exe+1E253B // goto zoom out from first person
eqgame.exe+1E2501 - E9 00000000           - jmp eqgame.exe+1E2506 // goto zoom out 2
zoom out 2:
eqgame.exe+1E2506 - D9 05 C0967900        - fld dword ptr [eqgame.exe+3996C0] // load third person camera zoom value
eqgame.exe+1E250C - D8 1D 38855E00        - fcomp dword ptr [eqgame.exe+1E8538] // compare to zoom maximum value
eqgame.exe+1E2512 - DFE0                  - fnstsw ax
eqgame.exe+1E2514 - 9E                    - sahf 
eqgame.exe+1E2515 - 0F87 3F000000         - ja eqgame.exe+1E255A // if above zoom maximum value goto zoom out above max
eqgame.exe+1E251B - A1 CC947F00           - mov eax,[eqgame.exe+3F94CC] // player spawn
eqgame.exe+1E2520 - 8D 80 90000000        - lea eax,[eax+00000090] // offset to camera height offset, this is the zoom minimum value
eqgame.exe+1E2526 - D9 05 C0967900        - fld dword ptr [eqgame.exe+3996C0] // load third person camera zoom value
eqgame.exe+1E252C - D8 00                 - fadd dword ptr [eax] // add twice to multiply by two
eqgame.exe+1E252E - D8 00                 - fadd dword ptr [eax] // add twice to multiply by two
eqgame.exe+1E2530 - D9 1D C0967900        - fstp dword ptr [eqgame.exe+3996C0] // store to third person camera zoom value
eqgame.exe+1E2536 - E9 3C000000           - jmp eqgame.exe+1E2577 // goto original code
zoom out from first person:
eqgame.exe+1E253B - C6 05 68BE6300 02     - mov byte ptr [eqgame.exe+23BE68],02 // set camera view to third person
eqgame.exe+1E2542 - A1 CC947F00           - mov eax,[eqgame.exe+3F94CC] // player spawn
eqgame.exe+1E2547 - 8D 80 90000000        - lea eax,[eax+00000090] // offset to camera height offset, this is the zoom minimum value
eqgame.exe+1E254D - D9 00                 - fld dword ptr [eax] // load zoom minimum value
eqgame.exe+1E254F - D9 1D C0967900        - fstp dword ptr [eqgame.exe+3996C0] // store to third person camera zoom value
eqgame.exe+1E2555 - E9 1D000000           - jmp eqgame.exe+1E2577 // goto original code
zoom out above max:
eqgame.exe+1E255A - D9 05 38855E00        - fld dword ptr [eqgame.exe+1E8538] // load zoom maximum value
eqgame.exe+1E2560 - D9 1D C0967900        - fstp dword ptr [eqgame.exe+3996C0] // store to third person camera zoom value
eqgame.exe+1E2566 - E9 0C000000           - jmp eqgame.exe+1E2577 // goto original code
eqgame.exe+1E256B - C6 05 68BE6300 02     - mov byte ptr [eqgame.exe+23BE68],02 // set camera view to third person
eqgame.exe+1E2572 - E9 00000000           - jmp eqgame.exe+1E2577 // goto original code
original code:
eqgame.exe+1E2577 - 8B 46 34              - mov eax,[esi+34] // this is the original code that got overwritten by the jump to code cave #2
eqgame.exe+1E257A - 39 C7                 - cmp edi,eax // this is the original code that got overwritten by the jump to code cave #2
eqgame.exe+1E257C - E9 A9CCFBFF           - jmp eqgame.exe+19F22A // jump to the original code that comes after the jump to code cave #2
