EQMac MacroQuest

Extract to your EQMac folder where eqgame.exe is located.
Use eqgame_inject_dll.exe to inject the eqmac_mq.dll into eqgame.exe while the game is running.
A batch file is provided to inject the DLL for you.
The maps folder is needed in order to draw the in-game map.
You can change various options by editing the eqmac_mq.ini configuration file.
You can make a zone specific configuration file by creating a ZONENAME.ini in the zoneconfigs folder. (example: c:\eqmac\zoneconfigs\poknowledge.ini)
You can make a character specific configuration file by creating a CHARACTERNAME.ini file in the charconfigs folder (example: c:\eqmac\charconfigs\Soandso.ini)

Command List:
TODO

Missing DLLs?

Visual C++ Redistributable Packages for Visual Studio 2013
https://www.microsoft.com/en-us/download/details.aspx?id=40784
vcredist_x86.exe
vcredist_x64.exe
vcredist_arm.exe
