eq.WriteStringToChat("test")

eq.WriteStringToChatWithColor("test color", EQ_TEXT_COLOR_YELLOW)

local charInfo = eq.GetCharInfo()

eq.WriteStringToChat("GetCharInfo() Platinum: " .. charInfo.Platinum)
eq.WriteStringToChat("GetCharInfo() Gold: " .. charInfo.Gold)
eq.WriteStringToChat("GetCharInfo() Silver: " .. charInfo.Silver)
eq.WriteStringToChat("GetCharInfo() Copper: " .. charInfo.Copper)
