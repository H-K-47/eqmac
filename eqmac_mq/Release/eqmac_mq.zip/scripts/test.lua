require "./scripts/system/eqmac"

local eq = require("eq")
     
eq.WriteStringToChat("test")

eq.WriteStringToChatWithColor("test color", EQ_TEXT_COLOR_YELLOW)
