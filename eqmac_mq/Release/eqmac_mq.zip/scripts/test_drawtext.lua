function Event_DrawNetStatus()
    eq.DrawText("Test EQ_DrawText", 512, 384, EQ_TEXT_COLOR_LIGHT_GREEN)
end